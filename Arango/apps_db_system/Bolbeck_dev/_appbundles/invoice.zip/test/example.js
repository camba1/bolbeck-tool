/*global describe, it */
'use strict';
const expect = require('chai').expect;

describe('science', function () {
  it('works', function () {
    expect(true).not.to.equal(false);
  });
});
