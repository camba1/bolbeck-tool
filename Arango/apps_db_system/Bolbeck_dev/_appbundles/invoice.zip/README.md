# invoice

Get invoices from the DB

# License

Copyright (c) 2018 Juan Peredo

License: Apache2