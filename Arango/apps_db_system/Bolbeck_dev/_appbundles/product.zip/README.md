# product

Returns information related to products

# License

Copyright (c) 2018 Juan Peredo

License: GNU GPL